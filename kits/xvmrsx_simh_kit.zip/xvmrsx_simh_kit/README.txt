				XVM/RSX V1B
				-----------

XVM/RSX is a general-purpose realtime operating system for the PDP-15. It is an
enhanced version of RSX-PLUS (not to be confused with RSX-11M Plus), which is 
itself an enhanced version of the original RSX-15. 


Contents of this kit
--------------------

README.txt		This file
xvmrsx_rp02.dsk		XVM/RSX V1B RP02 disk image (also includes XVM/DOS)
xvmrsx_boot		XVM/RSX SIMH configuration file (Unix executable script)
xvmrsx_boot.ini		XVM/RSX SIMH configuration file (Windows/DOS format)
xvmrsx_install.html	Guide to installing XVM/RSX
rpboot.rim		XVM/DOS RP02 bootstrap paper tape image
build_files		Directory containing SIMH configuration files and XVM/DOS batch files for building XVM/RSX


Running XVM/RSX in SIMH
-----------------------

XVM/RSX will not run properly in versions of SIMH prior to 3.7-0 due to bugs in
the KM15/KT15/XM15 MMU emulation.

To run XVM/RSX in SIMH, run pdp15 with the configuration file xvmrsx_boot 
or xvmrsx_boot.ini. The two files are basically identical, except xvmrsx_boot
has Unix-style (LF) line endings and has two lines at the beginning to make it 
executable on most Unices, and xvmrsx_boot.ini has Windows/DOS-style line 
endings (CR/LF) and does not have the lines to make it executable.

XVM/RSX boots from XVM/DOS and uses the same filesystem as it. When SIMH is run
with the XVM/RSX configuration file, it will boot into XVM/DOS. XVM/DOS will
prompt for the date, and once the date is entered (the year must in the range 
70-99), the XVM/DOS keyboard monitor prompt will appear. To boot XVM/RSX, use
the XVM/DOS command "RSX".

Up to five extra terminals can be used while XVM/RSX is running. To access an
extra terminal, telnet to the host that is running the simulator (usually
localhost) on port 2311. This port is set in the configuration file, and can be
changed if something else is using it. It is possible to telnet to the
simulator multiple times to access more terminals. To bring up the login
prompt, press Ctrl-T on an extra terminal (it is also possible to do this on
the console, but it will interfere with MCR if it is active (press escape or 
wait 30 seconds for MCR to deactivate)). Type a disk device name and UIC at the
login prompt to log in. To log out, use the TDV command "OFF".

It is possible to log in with any UIC (even XVM/DOS system UFDs) under XVM/RSX.
if the specified UFD does not exist, it is created.

UICs with UFDs on the included disk:
IOS	XVM/DOS device handlers; cannot log in under XVM/DOS
BNK	XVM/DOS bank-mode utilities and libraries; cannot log in under XVM/DOS
PAG	XVM/DOS page-mode utilities and libraries; cannot log in under XVM/DOS
BLD	UIC used when building XVM/DOS
SCR	Default UIC under XVM/DOS; used when installing XVM/RSX
RSX	RSX system UFD

Documentation
-------------

The XVM/RSX System Manual is available from
http://www.bitsavers.org/pdf/dec/pdp15/DEC-XV-IRSMA-A_XVM-RSXsysMan/ , but it 
is missing everything after chapter 5.

I am currently writing a guide to XVM/RSX MCR and TDV commands (based partially on the XVM/RSX sources, and partially on the XVM/RSX System Manual), and will
release an updated version of this kit once the guide is complete.  

Extracted versions of the XVM/RSX sources can be found at http://www.bitsavers.org/bits/DEC/pdp15/dectape/XVM_RSX/_textfiles/ . Most of the source files have
reasonably good comments, so it is possible to understand some of what is 
happening even if you are not familiar with PDP-15 assembly.

For instructions on how to install a new XVM/RSX system (not necessary for just
using the pre-installed image in this kit), see xvmrsx_install.html (or 
xvmrsx_install.txt).

If you have any questions, feel free to email me.

Andrew Warkentin
andreww@datanet.ab.ca
