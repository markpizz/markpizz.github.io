[Notes from Hans Pufal, Grenoble, France; hansp@aconit.org]

			   D I G I T A L  DOS-15  V2A
			   --------------------------

DOS-15 was a disk based operating system developed from the DECtape based
PDP-9 ADSS. Despite the names of these systems, they both work on PDP-9's and
PDP-15's.

DOS-15 was thought to have been lost, but while examining a batch of DECtapes
which were associated with a PDP-9 we were restoring, I came across 3 tapes
labelled as being an update to the DOS system. Subsequently these tapes were
dumped to file images and analysed.

With hints from various documents, the format of the tapes was established as
being DOS dump tapes. No copies of the papertape program DOSSAVE used to
restore such tapes to a disk image have so far been found, but a C program was
written to perform this function.

With a DOS image disk in hand, we faced the problem of booting. No copies of
the DOS bootstrap have so far surfaced. It was noticed that the boot process
of ADSS and of DOS were quite similar and that the interface to the DECtape
ADSS bootstrap was identical to that described for the DOS bootstrap. We
therefore adapted the source code of the ADSS RF bootstrap and after a
couple of tries managed to make it boot DOS.

After fixing a couple of minor emulator bugs we had a working DOS system!

Anyone with copies of the missing pieces: the DOSSAVE and original
bootstrap paper tapes and documentation are urged to contact the author
with a view to making them available on this archive.


Installation
============

DOS-15 was distributed on two DECtapes or a mag tape. This is the DECtape
release. The two files UPDATE1.DTA and UPDATE2.DTA are SIMH DECtape image
files of the two tapes. There is a third DECtape called PER with some
auxiliary files.

UPDATE1 and UPDATE2 are dump tapes of a 1 platter DOS system. To build a
disk image, compile DOSSAVE (or use the prebuilt Windows .exe) and run it
as follows

      DOSSAVE [p] <tape-name> > <disk-name>

where the optional parameter p specifies the number of RF platters, the default
is 1, the maximum is 7. (See section below on 8 platter disk).

The tape name should be UPDATE1.DTA for the first tape.  At the end of the
first tape, DOSSAVE will change the 1 to a 2 and read the second tape.

Output from DOSSAVE is to stdout and should be redirected to an RF image file,
e.g., to set up a 2 platter DOS disk image run as follows:

      DOSSAVE 2 UPDATE1.DTA >DOS_2P.RF

The DOS bootstrap file, RFSBOOT.RIM, is a reconstruction, since an original
copy has not yet been found. The assembler source to the bootstrap is
provided in the file RFSBOOT.ASM.

Check the DOS.INI file for correct file names and paths and then boot DOS
by issuing the command:

      PDP15 DOS.INI

DOS should boot and ask for the date. I use 1973 as a year so as not to
confuse DOS with Y2K and other date issues.

Note that the INI file has attached the file CHECKOUT.BT to the PTR. This
file is typed in from a DEC manual. CHECKOUT was also shipped as a
papertape with DOS systems. It excersies the DOS system and ensures that
it is working correctly.

To run the checkout, issue the following command at the DOS $ prompt:

      BATCH PR

The procedure will perform some PIP transfers and then compile a Fortran
program and assemble a macro file, then link and execute the resulting
program. I have found it instructive to study the commands issued.


Documentation
=============

The following documents have been recovered:

  Docuemnt title:                    DEC reference:      Date:

  DOS User Manual                    DEC-15-ODUMA-A-D    Dec 1972
  DOS System Manual                  DEC-15-ODFFA-A-D    Jul 1972
  SGEN-DOS utility program           DEC-15-YWZB-DN12    Oct 1971
  PIP DOS monitor utility program    DEC-15-YWZB-DN13    Apr 1972

The User Manual is availabe as a 13MB PDF file at
 http://www.aconit.org/hbp/PDP9/DOS/DEC-15-ODUMA-A-DOS15_UserManual.pdf

DOS manuals are also available at Al Kossow's excellent document archive:
http://www.spies.com/~aek/pdf/dec/pdp15/ :

  File name: 			   Document title:	      Date:

  DEC-15-YWZA-D_Utilities.pdf      PDP-15 Utility Programs    Oct 1969
  DEC-15-YWZA-DN3.pdf              SGEN System Generator      Sep 1970

Scans of documents not already available at Al's site will be made
available soon.


Line Printer
============

The LPA.;BIN driver in the <IOS> directory of the release is an LP09 driver.
The system skip chain is not gen'd correctly to support that printer and
any attempt to use the printer will result in an IOPS5 error.

To fix this issue, run the LPA.BT batch which will install the new LPA15
driver.

This process starts at the SIMH prompt by attaching the batch tape image
file to the PTR and the PER tape image to DT1 :


> at -a ptr lpa.bt
> at dt1 per.dta
> cont

At the DOS $ prompt issue the following command :

$ BATCH PR

The correct printer driver will be assembled and copied to its correct
place on the system disk.


Prebuilt RF Disk Image
======================

The distribution includes a prebuilt 4 platter RF disk image of DOS-15.
The line printer driver fix has already been applied.  To use this image,
start the PDP-15 simulator and issue these commands:

> at -e rf dosv2a_4p.rf
> load rfsboot.rim 77637
> run

DOS should boot and ask for the date, as described above.


8 Platter Disks
===============

During the process of bringing up DOS V2A we noticed that it would not work
on an 8 platter RF system. The system would boot to the $ prompt and all
resident commands worked but any attempt to load a program resulted in an
IOPS21 error : invalid disk address.

Investigations of this error led to a patch to the resident binary image on
the first DECtape image. With this patch, we could successfully load programs
but now any attempt to use any of the three DK drivers provoked the IOPS21
error again.

We determined that there are, in effect, 4 DK drivers on the system tapes,
the first being in the resident image, the other three being the DKA.;BIN,
DKB.;BIN and DKC.;BIN files in the <IOS> directory. Each of these drivers
have the same bug: they declare an IOPS 21 error when they determine that the
number of platters on the RF subsystem is greater than 7. As far as we can
tell this is bug was extant at the time of the release from DEC implying that
no user had an 8 platers system and further that DEC never tested such a
configuration.

The patch we developped for the resident image was adapted for the DK drivers,
a problem complicated by the fact that the DK drivers were relocatable object
files, not pure binary load images. The file 8P.BT is the result. 

The procees to make an 8 platter RF image is as follows:

Starting wiht copies of the two DECtape system image tapes, mount the first on
DTA1 and the second on DTA2.  Attach, in ASCII mode the file 8P.BT to PTR.
Boot aworking version of DOS V2A.

At the DOS $ prompt issue the command 'BATCH PR' and verify that the resulting 
console output corresponds with the listing shown below.

   
$BATCH PR

DOS-15 V2A
$$JOB
A DTA1 -14

$PATCH
PATCH V10A
>B 051
>L 0111
>00111/615231>741000
 00112/615077>
>
>$JOB
DOS-15 V2A
$A DTA2 -14

$PATCH
PATCH V10A
>B 0211
>
>L 064
>00064/015000>
 00065/351167>213554
 00066/040404>
 00067/700000>
 00070/707065>
 00071/700000>
 00072/040403>
 00073/700000>
 00074/707001>
 00075/602463>
 00076/040304>
 00077/707242>
 00100/602470>
 00101/707242>
 00102/030303>030304
 00103/343623>
 00104/544224>
 00105/603366>741000
 00106/030304>
>
>B 0210
>L 0150
>00150/015000>
 00151/502301>334233
 00152/040404>
 00153/750000>
 00154/707045>
 00155/700000>
 00156/040404>
 00157/700000>
 00160/700000>
 00161/707065>
 00162/040404>
 00163/700000>
 00164/700000>
 00165/707001>
 00166/030403>
 00167/602027>
 00170/707242>
 00171/602034>
 00172/040303>
 00173/707242>
 00174/343163>
 00175/543560>
 00176/030303>040303
 00177/602732>741000
 00200/602020>
>
>B 0254
>L 0320
>00320/015000>
 00321/370124>230443
 00322/040404>
 00323/700000>
 00324/707065>
 00325/700000>
 00326/040403>
 00327/700000>
 00330/707001>
 00331/601165>
 00332/040304>
 00333/707242>
 00334/601172>
 00335/707242>
 00336/030303>030304
 00337/341526>
 00340/542141>
 00341/601320>741000
 00342/030304>
>
>
>

DOS-15 V2A
$
-------------------------------------------------

	At this point exit SIMH and build an 8 platter RF image using
	the two patched DECtape images:


C:\SIMH\dos>dossave 8 patched1.dta >dosv2a_8p.rf
DOSSAVE version 2.0, 12 February 2003
SAT T :   2000   2000  21703 ...    413 777777
SAT 2 :  20000   7132      0 ...   1777 777777
SAT 1 :  20000  10646   1561 ... 777777   1775


	Check that a DOSSAVE version message appears and that the version
	is at least 2.0.

	Now restart SIMH using that new image and verify that it is working
	First load PIP and do a DK listing, verify that 
	    1) PIP loads and 
	    2) the number of free blocks is 16217
	Then set slots 11 and 12 to DKB and DKC and reload PIP
	If PIP loads then the drivers are patched correctly.

C:\SIMH\adss15\dos>pdp15 dos.ini

PDP-15 simulator V2.10-2
RF: buffering file in memory [2097152]

DOS-15 V2A
 ENTER DATE (MM/DD/YY) - 2/13/73

$PIP

DOSPIP V6A

>L TT _ DK

     13-FEB-73
 DIRECTORY LISTING  (SCR)
  16217 FREE BLKS
      0 USER FILES
      0 USER BLKS


>^C

DOS-15 V2A
$A DKB 11

$A DKC 12

$PIP

DOSPIP V6A

>

	All done, enjoy your 8 platter RF DOSS V2A system.


Disk Packs
==========

Using the following sequence you can initialize and empty diskpack and use
it for user files.

> attach rp1 user.rp

MICLOG SYS
PIP
I DPA1
N DPA1 <USR>
L TT _ DPA1 <USR>

Use of packs as system disk requires the development of a new bootstrap and
extensions to DOSSAVE to properly build a system pack (anyone volounteer?).

							     Hans B Pufal
					   http://www.aconit.org/hbp/PDP9
							 hansp@aconit.org
							    February 2003












