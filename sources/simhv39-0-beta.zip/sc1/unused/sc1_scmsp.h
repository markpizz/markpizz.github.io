/* simulated SC MSP register */

#include "sicortex/ice9/ice9_scb_spec_sw.h"

#define SCMSPBASE         (ICE9_RA_ScbAtnChip)
#define SCMSPEND          (ICE9_RAE_ScbAtnChip)
#define SCMSPSIZE	  (SCMSPEND - SCMSPBASE)
