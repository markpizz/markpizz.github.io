
#include <sys/types.h>
#include <stdint.h>

int64_t sim_magic_pipe_instruction(uint64_t reg_val);
